import requests

def send_notification(ID):
     return requests.post(url('/notifications/'), json=ID)
	  
def verify_notification(id):
     return requests.get(url('/notifications/{:d}/'.format(id)))

def update_passcodes(ID):
     return requests.post(url('/pass_codes/'), json=ID)
	
def create_passcodes(ID):
     return requests.put(url('/pass_codes/'), json=ID)
   
def get_passcodes(id):
     return requests.get(url('/pass_codes/{:d}/'.format(id)))

def get_all():
     return requests.get(url('/pass_codes/')
	
def url(path):
     return 'http://18.233.171.56:8080/v1' + path	