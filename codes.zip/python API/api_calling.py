import myApi
import datetime

notify=0

ID = {"notification_id": notify,"product_id": "","pass_code":"" , "created_ts":datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}

resp = myApi.send_notification(ID)
if resp.status_code != 201:
    raise ApiError('Cannot send notification: {}'.format(resp.status_code))
print('notification sent. ID: {}'.format(resp.json()["id"]))


notify = notify+1

resp=send_notification(ID)
if resp.status_code != 200:
    raise ApiError('Cannot fetch all tasks: {}'.format(resp.status_code))
for todo_item in resp.json():
    print('{} {}'.format(todo_item['notification_id'], todo_item['product_id']))
	
	
	
	
	---------------------
	
	
import requests
import datetime
import time

notify=2345
ID = {"notification_id": notify,"product_id": "","pass_code":"" , "created_ts":datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}

def _url(path):
    return 'http://18.233.171.56:8080/v1'+ path

def send_notification(ID):
     return requests.post(_url('/notifications/'), json=ID)
    
	  
def verify_notification(id):
     return requests.get(_url('/notifications/{:d}/'.format(id)))
def update_passcodes(ID):
     return requests.post(url('/pass_codes/'), json=ID)
	
def create_passcodes(ID):
     return requests.put(url('/pass_codes/'), json=ID)
   
def get_passcodes(id):
     return requests.get(url('/pass_codes/{:d}/'.format(id)))

resp=send_notification(ID)
if resp.status_code != 200:
    print(resp.status_code)
else:
    print('done')
    

