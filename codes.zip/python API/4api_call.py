import json
import uuid
from uuid import UUID  

#------------- generating UUID ------------------------

notify = uuid.uuid4() 
class UUIDEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, UUID):
            # if the obj is uuid, we simply return the value of uuid
            return obj.hex
        return json.JSONEncoder.default(self, obj)
    
id=json.dumps(notify, cls=UUIDEncoder)

fd=str(notify)
#-------------- End Generating UUID ------------------------------------------------

ts=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] 

#ID = {"notification_id":fd,"product_id": "Box-182","pass_code":"3456" , "created_ts":ts}

ID= {
   "notification_id" : fd,
   "product_id" : "SmartBox-Test",
   "event" : "BOX_flew",
   "event_ts" :ts
   }
   



def _url(path):
    return 'http://18.233.171.56:8080/v1'+ path

def send_notification(ID):
     return requests.post(_url('/notifications/'), json=ID)
    	  
def verify_notification(id):
     return requests.get(_url('/notifications/{:s}/'.format(id)))
def update_passcodes(ID):
     return requests.post(url('/pass_codes/'), json=ID)
	
def create_passcodes(ID):
     return requests.put(_url('/pass_codes/'), json=ID)
   
def get_passcodes(id):
     return requests.get(_url('/pass_codes/{:s}/'.format(id)))
	 
	 



## --------------------Send Notification call starts here -----------------------
# resp=send_notification(ID)
# if resp.status_code != 200:
   # print(resp.status_code)
# else:
   # print('done')
   
  # # result= resp.content.decode("utf-8")
# #print(result)
# print(ID)
# -----------------------------$$$$$$$$$$$$---------------------------------------*/	 



## --------------------Create Passcode call starts here -----------------------
# resp=create_passcodes(BOX)
# if resp.status_code != 200:
   # print(resp.status_code)
# else:
   # print('done')
   
  # # result= resp.content.decode("utf-8")
# #print(result)

#----------------------------$$$$$$$$$$$$---------------------------------------


# ## --------------------Request pass_code starts here -----------------------
# resp=get_passcodes(ID["product_id"])
# if resp.status_code != 200:
   # print(resp.status_code)
# else:
   # print('done')
   
   # result= resp.content.decode("utf-8")
# print(result)
# print(ID["product_id"])
	 
# -----------------------------$$$$$$$$$$$$---------------------------------------*/	 
