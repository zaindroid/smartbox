import requests

notify=0

ID = {"notification_id": notify,"product_id": "","pass_code":"" , "created_ts":"date,time"}

notify = notify+1

def send_notification(json=ID):
    return requests.post(_url('/notifications/'), json=ID)
def verify_notification(id=ID["notification_id"]):
    return requests.get(_url('/notifications/{:d}/'.format(id)))

def update_passcodes(json=ID):
    return requests.post(_url('/pass_codes/'), json=ID)
	
def create_passcodes(json=ID):
   return requests.put(_url('/pass_codes/'), json=ID)
   
def  get_passcodes(id=ID["product_id"]):
     return requests.get(_url('/pass_codes/{:d}/'.format(id)))

def  get_all():
    return requests.get(_url('/pass_codes/')
	
def _url(path):
    return 'http://18.233.171.56:8080/v1' + path	