#!/usr/bin/env python

from picamera import PiCamera
from time import sleep
import Adafruit_DHT
import time
import datetime
import os
import ftplib
import json
import serial

ser = serial.Serial(
 port='/dev/ttyUSB0',
 baudrate = 9600,
 parity=serial.PARITY_NONE,
 stopbits=serial.STOPBITS_ONE,
 bytesize=serial.EIGHTBITS,
 timeout=1
)
counter=0



sensor = Adafruit_DHT.DHT22
pin = 4

os.chdir('/home/pi/Desktop/videos/')

camera = picamera.PiCamera()

session = ftplib.FTP('50.62.188.189','pi@swim.tools','zain@pi1')

user_name='pi@swim.tools'
password='zain@pi1'

print (session.getwelcome())


try:
    print ("Logging in...")
    ftp.login("user_name", "password")
	   
except:
    "failed to login"
    

h, t = Adafruit_DHT.read_retry(sensor, pin)    
	
	
	
while 1:
 x=ser.readline()
 print x
 #data=json.dumps(x)
 if x=="success":	
     name=datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
     camera.start_recording(name+".h264")
     sleep(15)
     camera.stop_recording()
     file = open('/home/pi/Desktop/videos/'+name+'.h264','rb')
	 session.storbinary('STOR '+name+'.h.264', file)
	 file.close()
	 sleep(2)
     h, t = Adafruit_DHT.read_retry(sensor, pin)
	 
	 # box status through API goes here
	 
 elif x == "unsuccessful":
	 name=datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
     camera.start_recording(name+".h264")
     sleep(15)
     camera.stop_recording()
     file = open('/home/pi/Desktop/videos/'+name+'.h264','rb')
	 session.storbinary('STOR '+name+'.h.264', file)
	 file.close()
	 sleep(2)
     
	 # box status through API goes here
      

